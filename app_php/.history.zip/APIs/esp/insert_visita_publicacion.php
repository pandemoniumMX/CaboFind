<?php
include '../../conn.php';

$ID=$_GET['ID'];

$sql=$conn->query("

INSERT INTO `trigger_visita_publicacion` (IDIOMA_TVP, publicacion_ID_PUBLICACION) VALUES ('esp','$ID')

");

$result=array();

while($fetchdata=$sql->fetch_assoc()) {
    $result[]=$fetchdata;

     }

/*
while($fetchdata=$sql->fetch_assoc()){
	$result[]=$fetchdata;
}*/
echo json_encode($result);
?> 